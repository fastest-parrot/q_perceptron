# q_perceptron

Requires Cython and Visual Studio C++ compiler to work on Windows 10 (recommended)

http://qutip.org/docs/latest/installation.html#installation-on-ms-windows

Or you could be lame and install via conda (not recommended)

## Overview

Currently a single layer perceptron suited for binary classification problems. Supports 